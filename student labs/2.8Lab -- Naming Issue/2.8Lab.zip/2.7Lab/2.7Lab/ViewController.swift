//
//  ViewController.swift
//  2.7Lab
//
//  Created by Snir Avrahami on 8/31/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

