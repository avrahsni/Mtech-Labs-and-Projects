//
//  PlayerTableViewCell.swift
//  Score Keeper App
//
//  Created by Snir Avrahami on 11/7/22.
//

import UIKit

class PlayerTableViewCell: UITableViewCell {
    
    @IBOutlet weak var playerNameLabel: UILabel!
    @IBOutlet weak var playerScoreLabel: UILabel!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    
    func update(with player: Player) {
        playerNameLabel.text = player.name
        playerScoreLabel.text = "\(player.score)"
        
    }
    

}
