//
//  TableViewController.swift
//  Score Keeper App
//
//  Created by Snir Avrahami on 11/7/22.
//

import UIKit

class TableViewController: UITableViewController {
    
    var players = [Player]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 136.0
        
        players = Player.loadFromFile() ?? [Player]()
        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return players.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "playerCell", for: indexPath) as! PlayerTableViewCell
        
        let player = players[indexPath.row]
        
        cell.update(with: player)

        return cell
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    
    
    
    
    // MARK: - Navigation
    
    @IBSegueAction func addPlayerSegue(_ coder: NSCoder, sender: Any?) -> AddPlayerViewController? {
        return AddPlayerViewController(coder: coder)
    }
//    @IBAction func unwindToTableView(_ unwindSegue: UIStoryboardSegue) {
//        let segue = unwindSegue
//        guard segue.identifier == "saveUnwind",
//                let sourceViewController = segue.source
//                   as? AddPlayerViewController,
//                let player = sourceViewController.player else { return }
//
//            if let selectedIndexPath = tableView.indexPathForSelectedRow {
//                players[selectedIndexPath.row] = player
//                tableView.reloadRows(at: [selectedIndexPath], with: .none)
//            } else {
//                let newIndexPath = IndexPath(row: players.count, section: 0)
//                players.append(player)
//                tableView.insertRows(at: [newIndexPath], with: .automatic)
//            }
//        Player.saveToFile(players: players)
//    }
    
//    @IBAction func unwindToTableView(_ unwindSegue: UIStoryboardSegue, sender: Any?) {
//        print("Save Button Pressed")
//        guard /*segue.identifier == "saveUnwind",*/ let sourceViewController = unwindSegue.source as? AddPlayerViewController, let player = sourceViewController.player else { return }
//
//
//        let newIndexPath = IndexPath(row: players.count, section: 0)
//        players.append(player)
//        tableView.insertRows(at: [newIndexPath], with: .automatic)
//
//        Player.saveToFile(players: players)
//        print("Save Button Pressed")
//    }
    
    @IBAction func unwindToThing(_ unwindSegue: UIStoryboardSegue) {
        print("hit")
    }
    
    
}
